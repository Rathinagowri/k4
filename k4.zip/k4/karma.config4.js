module.exports = function(config) {
  config.set({
    
    colors: true,
    autoWatch: true,
   
    
    files: [
    'lib/*.js',
    'test/*.js'],
    
  });
}
