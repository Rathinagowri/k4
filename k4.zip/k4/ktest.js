describe("Check",function(){
	
it("check whether a value is defined or not", function() {
   
    expect(def(a)).toBeDefined();

  });


})
