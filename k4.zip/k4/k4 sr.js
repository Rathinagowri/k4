function def(){
		var a = "10";
}